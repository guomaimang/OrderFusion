-- MySQL dump 10.13  Distrib 5.7.39, for Linux (x86_64)
--
-- Host: localhost    Database: orderfusion-dev
-- ------------------------------------------------------
-- Server version	5.7.39-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `goods`
--

DROP TABLE IF EXISTS `goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goods` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` longtext,
  `image_uri` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `is_available` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods`
--

LOCK TABLES `goods` WRITE;
/*!40000 ALTER TABLE `goods` DISABLE KEYS */;
INSERT INTO `goods` VALUES (1,'MS365 EDU SKU A3','Microsoft 365 for Education',NULL,NULL,33.58,100,1),(2,'MS365 EDU SKU A1','Microsoft 365 for Education',NULL,NULL,9.99,80,1),(3,'MS365 EDU SKU A5','Microsoft 365 for Education',NULL,NULL,69.98,200,1),(4,'Minecraft Education Add-on For MS365 ORG','Minecraft Education',NULL,NULL,39.98,100,1),(5,'Add-on For MS365 ORG','Microsoft Copilot',NULL,NULL,39.98,100,1),(6,'Add-on For MS365 ORG','Power BI Pro',NULL,NULL,19.98,100,1),(7,'Add-on For MS365 ORG','Defender for Endpoint',NULL,NULL,85.50,100,1),(8,'Add-on For MS365 ORG','Microsoft Purview',NULL,NULL,40.00,80,1),(9,'Standard Plan, Add-on For MS365 ORG','Microsoft Teams',NULL,NULL,15.00,90,1),(10,'Standard Plan, 1TB per user.','SharePoint Plan1',NULL,NULL,19.99,98,1),(11,'Standard Plan, 5TB per user.','SharePoint Plan2',NULL,NULL,39.99,100,1),(12,'Standard Plan, 100GB per user.','SharePoint Plan for Education','<h2 id=\"9iita\">Sharepoint Plan!</h2><ul><li>Get SharePoint features for small and medium-sized businesses</li><li>Securely share files inside or outside your organization and co-author in real time</li><li>Manage content in document libraries with version control and access control</li><li>Search and discover relevant people and content when you need it most</li></ul>','https://pic.hanjiaming.com.cn/2024/03/11/745889d753016.jpg',39.99,100,0);
/*!40000 ALTER TABLE `goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL,
  `goods_id` int(10) NOT NULL,
  `goods_name` varchar(255) NOT NULL,
  `goods_amount` int(10) NOT NULL,
  `payment` decimal(10,2) NOT NULL,
  `delivery_address` varchar(255) DEFAULT NULL,
  `delivery_phone` varchar(255) DEFAULT NULL,
  `delivery_receiver` varchar(255) DEFAULT NULL,
  `user_remark` varchar(255) DEFAULT NULL,
  `admin_remark` varchar(255) DEFAULT NULL,
  `status` int(1) DEFAULT '0' COMMENT '0 not paid, 1 paid, 2 sent out, 3 finished, 4 refunded, 5 cancelled',
  `create_time` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `pay_time` datetime DEFAULT NULL,
  `sent_time` datetime DEFAULT NULL,
  `channel` int(1) NOT NULL DEFAULT '0' COMMENT '0 general, 1 seckill, 2 admin create',
  `pay_id` int(10) DEFAULT NULL,
  `seckill_event_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES (1,1,11,'SharePoint Plan2',2,79.98,'address','phone','hs','remaekew',NULL,0,'2024-03-14 17:55:18',NULL,NULL,0,NULL,NULL),(2,1,10,'SharePoint Plan1',3,59.97,'adtdress','phontie','44','remaek4ew',NULL,0,'2024-03-14 17:59:08',NULL,NULL,0,NULL,NULL),(3,1,10,'SharePoint Plan1',4,79.96,'agwedtdress','phontewewtie','44wrtwerg','remaek4tertew',NULL,0,'2024-03-14 18:02:39',NULL,NULL,0,NULL,NULL),(4,1,10,'SharePoint Plan1',6,119.94,'reeerwe','phontrweewewtie','44wrtwerg','remaek4tertew',NULL,0,'2024-03-14 18:03:32',NULL,NULL,0,NULL,NULL),(5,1,10,'SharePoint Plan1',6,119.33,'reeerwe','phontrweewewtie','44wrtwerg','remaek4tertew',NULL,0,'2024-03-25 00:39:59','2024-03-25 00:29:13',NULL,0,13,NULL),(6,1,10,'SharePoint Plan1',6,119.94,'reeerwe','phontrweewewtie','44wrtwerg','remaek4tertew',NULL,1,'2024-03-25 00:40:06','2024-03-25 00:54:49',NULL,0,15,NULL),(7,1,10,'SharePoint Plan1',2,39.98,'reeerwe','phontrweewewtie','44wrtwerg','remaek4tertew',NULL,0,'2024-03-25 00:40:10','2024-03-25 00:17:48',NULL,0,9,NULL),(8,1,10,'SharePoint Plan1',2,39.98,'reeerwe','phontrweewewtie','44wrtwerg','remaek4tertew',NULL,0,'2024-03-25 00:40:15','2024-03-24 23:51:25',NULL,0,6,NULL),(9,1,10,'SharePoint Plan1',2,39.98,'5555555555555','phontrweewewtie','44wrtwerg','remaek4tertew',NULL,1,'2024-03-25 00:40:18','2024-03-25 00:42:47',NULL,0,14,NULL),(10,2,10,'SharePoint Plan1',2,39.98,'reeerwe','phontrweewewtie','44wrtwerg','ssdscew',NULL,0,'2024-03-18 15:04:49',NULL,NULL,0,NULL,NULL),(11,1,10,'SharePoint Plan1',12,239.88,'12dfhsdusdvsdgvs','12','12','3额23e',NULL,0,'2024-03-25 00:40:21',NULL,NULL,0,NULL,NULL),(12,1,8,'Microsoft Purview',10,400.00,'121212','211212121','1212','123132412351435134',NULL,0,'2024-03-25 00:40:24','2024-03-25 00:13:34',NULL,0,7,NULL),(13,27,10,'SharePoint Plan1',2,39.98,NULL,NULL,NULL,NULL,NULL,0,'2024-03-25 18:24:16',NULL,NULL,0,NULL,NULL),(14,27,9,'Microsoft Teams',10,150.00,NULL,NULL,NULL,NULL,NULL,0,'2024-03-25 18:24:18',NULL,NULL,0,NULL,NULL),(15,27,8,'Microsoft Purview',10,400.00,NULL,NULL,NULL,NULL,NULL,0,'2024-03-25 18:24:19',NULL,NULL,0,NULL,NULL),(17,1,1,'nummmmmmm',1,19.90,NULL,NULL,NULL,NULL,NULL,0,'2024-03-25 18:24:25',NULL,NULL,0,NULL,NULL),(18,1,1,'nummmmmmm',1,19.90,NULL,NULL,NULL,NULL,NULL,0,'2024-03-25 18:14:58',NULL,NULL,0,NULL,NULL),(19,1,1,'nummmmmmm',1,19.90,NULL,NULL,NULL,NULL,NULL,0,'2024-03-25 18:23:28',NULL,NULL,0,NULL,NULL),(20,1,1,'nummmmmmm',1,19.90,NULL,NULL,NULL,NULL,NULL,0,'2024-03-25 18:26:29',NULL,NULL,1,NULL,1);
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay`
--

DROP TABLE IF EXISTS `pay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `method` int(1) DEFAULT NULL COMMENT '1 for PayCard, 2 for VirtualPay',
  `status` int(1) NOT NULL DEFAULT '0' COMMENT '0 for no 1 for success',
  `transaction_id` varchar(255) DEFAULT NULL,
  `pay_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay`
--

LOCK TABLES `pay` WRITE;
/*!40000 ALTER TABLE `pay` DISABLE KEYS */;
INSERT INTO `pay` VALUES (1,2,1,'Virtual Transaction ID','2024-03-24 23:00:51'),(2,2,1,'Virtual Transaction ID','2024-03-24 23:04:12'),(3,2,1,'Virtual Transaction ID','2024-03-24 23:39:27'),(4,2,1,'Virtual Transaction ID','2024-03-24 23:46:55'),(5,2,1,'Virtual Transaction ID','2024-03-24 23:49:53'),(6,2,1,'Virtual Transaction ID','2024-03-24 23:51:25'),(7,2,1,'Virtual ID: YU9GBa','2024-03-25 00:13:34'),(8,2,1,'Virtual ID: fnrTvl','2024-03-25 00:15:12'),(9,2,1,'Virtual ID: YjeAQC','2024-03-25 00:17:48'),(10,2,1,'Virtual ID: FFfQ2n','2024-03-25 00:18:43'),(11,2,1,'Virtual ID: JhjRfD','2024-03-25 00:20:23'),(12,2,1,'Virtual ID: ths0zz','2024-03-25 00:20:57'),(13,2,1,'Virtual ID: MIliOr','2024-03-25 00:29:13'),(14,2,1,'Virtual ID: lBXGd1','2024-03-25 00:42:47'),(15,2,1,'Virtual ID: gVcgKN','2024-03-25 00:54:49');
/*!40000 ALTER TABLE `pay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seckill_event`
--

DROP TABLE IF EXISTS `seckill_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seckill_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `seckill_price` decimal(10,2) NOT NULL,
  `seckill_stock` int(11) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL COMMENT '0 for no, 1 for yes',
  `is_available` int(1) NOT NULL DEFAULT '1',
  `purchase_limit_num` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seckill_event`
--

LOCK TABLES `seckill_event` WRITE;
/*!40000 ALTER TABLE `seckill_event` DISABLE KEYS */;
INSERT INTO `seckill_event` VALUES (1,1,'nummmmmmm',19.90,7,'2023-02-19 21:30:00','2024-03-25 22:30:00',1,2),(2,1,'ahah',19.90,12,'2023-02-19 21:30:00','2023-02-20 21:30:00',1,2),(3,1,'ah43254ah',19.90,12,'2023-02-19 21:30:00','2023-02-20 21:30:00',1,2),(4,1,'ah43254ah',19.90,12,'2023-02-19 21:30:00','2023-02-20 21:30:00',1,2),(5,1,'ah43254ah',19.90,12,'2023-02-19 21:30:00','2023-02-20 21:30:00',1,2),(6,1,'ah43254ah',19.90,12,'2023-02-19 21:30:00','2023-02-20 21:30:00',1,2),(7,1,'ah43254ah',19.90,12,'2023-02-19 21:30:00','2023-02-20 21:30:00',1,2),(8,1,'ah43254ah',19.90,12,'2023-02-19 21:30:00','2023-02-20 21:30:00',1,2),(9,1,'ah43254ah',19.90,12,'2023-02-19 21:30:00','2023-02-20 21:30:00',1,2),(10,1,'ah43254ah',19.90,12,'2023-02-19 21:30:00','2023-02-20 21:30:00',1,2),(11,1,'122123123fwsfvcqw',19.90,12,'2023-02-19 21:30:00','2023-02-20 21:30:00',1,2),(12,1,'ah43254ah',19.90,12,'2023-02-19 21:30:00','2023-02-20 22:30:00',1,2);
/*!40000 ALTER TABLE `seckill_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `email` varchar(256) NOT NULL,
  `password` varchar(64) NOT NULL,
  `random_salt` varchar(8) NOT NULL,
  `avatar_uri` varchar(255) DEFAULT NULL,
  `register_time` datetime NOT NULL,
  `is_frozen` int(11) NOT NULL DEFAULT '0',
  `is_admin` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNI_Email` (`email`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'hongshu','hanjiaming@asi.ac.cn','3a6c886ad184ad6360f35bb2c90b9e1809018e661976e5e6fc592363dfce9f39','ah28as',NULL,'2024-01-10 13:39:57',0,1),(2,'jsjs','hanji@eduhk','123','123salt',NULL,'2024-03-08 13:03:21',0,0),(7,'hanffsee','hanji@2df8dh','123','123salt',NULL,'2024-03-08 14:12:06',0,0),(8,'hajku','xj3i@h38dchj','dsjw3iod2','f4yrgI',NULL,'2024-03-08 16:50:53',0,0),(9,'dxneuduid','xj3ifggnrtgn38dchj','dsjw3dfgwiod2','t14alO',NULL,'2024-03-08 16:51:27',0,0),(10,'ahenj3','eju23jdokw','sdj3','diiFpV',NULL,'2024-03-08 16:52:43',0,0),(11,'ahefgwthnj3','eju2gergerq3jdokw','sdgertgj3','ypf9qb',NULL,'2024-03-08 16:52:49',0,0),(13,'ahefgwter23rfhnj3','eju2gergsderq3jdokw','sdgsdsfertgj3','ZOx3DR',NULL,'2024-03-08 17:19:16',0,0),(14,'ahefgwtgfghnj3','eju2gergdfgerq3jdokw','sdgegdfrtgj3','QdHxc6',NULL,'2024-03-08 18:21:30',0,0),(15,'ahefgwtgfdfgghnj3','eju2gerdggdfgerq3jdokw','sdgegddgfrtgj3','ubF1mr',NULL,'2024-03-08 18:21:34',0,0),(16,'ahefnj3','eju2gdokw','sdgegdfrtgj3','aVsLNK',NULL,'2024-03-08 18:21:38',0,0),(17,'ahefnj3','eju2gdfgdfokw','sdgegdfrtgj3','fxapen',NULL,'2024-03-08 18:21:40',0,0),(18,'ahefnj3','eju2dfgdfgdfokw','sdgegdfrtgj3','z+pvRT',NULL,'2024-03-08 18:21:42',0,0),(19,'ahefnj3','fvjruv','sdgegdfrtgj3','xQ1Iqo',NULL,'2024-03-08 18:21:46',0,0),(20,'ahefnj3','dfdfbd','sdgegdfrtgj3','G8KeW/',NULL,'2024-03-08 18:21:49',0,0),(21,'Li, Yuzeng','yuzeng.li@connect.polyu.hk','cd372fb85148700fa88095e3492d3f9f5beb43e555e5ff26d95f5a6adc36f8e6','//U+Pp',NULL,'2024-03-08 18:21:51',0,0),(22,'ahefnj3','dfddfgdgehdsfdfbd','sdgegdfrtgj3','3sTZPo',NULL,'2024-03-08 18:21:54',0,0),(23,'ahefnj3','df43dfbd','sdgegdfrtgj3','fAvCQw',NULL,'2024-03-08 18:21:58',0,0),(24,'ahefnj3','df4gergbd','sdgegdfrtgj3','x8pt6b',NULL,'2024-03-08 18:22:00',0,0),(25,'ahefnj32222','df4gergrebd','47a3d48b49118515ac7efb30d544a9e22aae69f944394e024487e51d763cf75b','ke6YgT',NULL,'2024-03-08 18:22:03',0,0),(26,'PEI, Yuxing','yuxing.pei@connect.polyu.hk','361fc396cfc170aed94542f3ea840b4dd3c897df028a3a512e3a636e3c07d18d','czNm+r',NULL,'2024-03-09 00:00:27',0,0),(27,'HAN, Jiaming [Student]','jiaming.han@connect.polyu.hk','5698ebb8badbdd310797895776b7eaba53fbaf7b89f04670f4b34092f482b4cd','UrCSoY',NULL,'2024-03-24 22:17:25',0,0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'orderfusion-dev'
--

--
-- Dumping routines for database 'orderfusion-dev'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-25 23:39:58
